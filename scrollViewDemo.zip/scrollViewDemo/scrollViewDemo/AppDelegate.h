//
//  AppDelegate.h
//  scrollViewDemo
//
//  Created by CuiJianZhou on 16/4/28.
//  Copyright © 2016年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

